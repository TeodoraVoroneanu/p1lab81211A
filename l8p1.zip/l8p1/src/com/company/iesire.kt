//import com.company.interAND

class iesire: interAND {
    override fun rez() {
        print("Poarta s-a creat")
    }
}