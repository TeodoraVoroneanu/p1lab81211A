data class and4(override var bridge: interAND?): AND(bridge) {
    private var intrare1: Boolean=false
    private var intrare2: Boolean=false
    private var intrare3: Boolean=false
    private var intrare4: Boolean=false
    fun i1(i1: Boolean)=apply{this.intrare1=i1}
    fun i2(i2: Boolean)=apply{this.intrare2=i2}
    fun i3(i3: Boolean)=apply{this.intrare3=i3}
    fun i4(i4: Boolean)=apply{this.intrare4=i4}
    override fun constrGATE() {
        print("Poarta and cu 4 intrari: ")
        bridge?.rez()
        println("\nRez pt and4: "+((intrare1.and(this.intrare2)).and(this.intrare3) and(this.intrare4)))
    }
}