abstract class AND(protected open var bridge: interAND) {
    abstract fun constrGATE()
}