interface interAND{
    fun rez()
}