data class and8(override var bridge: interAND?): AND(bridge) {
    private var intrare1: Boolean=false
    private var intrare2: Boolean=false
    private var intrare3: Boolean=false
    private var intrare4: Boolean=false
    private var intrare5: Boolean=false
    private var intrare6: Boolean=false
    private var intrare7: Boolean=false
    private var intrare8: Boolean=false
    fun i1(i1: Boolean)=apply{this.intrare1=i1}
    fun i2(i2: Boolean)=apply{this.intrare2=i2}
    fun i3(i3: Boolean)=apply{this.intrare3=i3}
    fun i4(i4: Boolean)=apply{this.intrare4=i4}
    fun i5(i1: Boolean)=apply{this.intrare5=i1}
    fun i6(i2: Boolean)=apply{this.intrare6=i2}
    fun i7(i3: Boolean)=apply{this.intrare7=i3}
    fun i8(i4: Boolean)=apply{this.intrare8=i4}
    override fun constrGATE() {
        print("Poarta and cu 8 intrari: ")
        bridge?.rez()
        println("\nRez and cu 8 intrari: "+((intrare1.and(this.intrare2)).and(this.intrare3) and(this.intrare4)and(this.intrare5)and(this.intrare6)and(this.intrare7)and(this.intrare8)))
    }
}