//import com.company.interAND

data class and2 (override var bridge: interAND?): AND(bridge) {
    private var intrare1: Boolean=false
    private var intrare2: Boolean=false
    fun i1(i1: Boolean)=apply{this.intrare1=i1}
    fun i2(i2: Boolean)=apply{this.intrare2=i2}
    override fun constrGATE() {
        print("Poarta and cu 2 intrari: ")
        bridge?.rez()
        println("\nRaspuns and2 "+(intrare2.let{intrare1.and(it)}))
    }
}