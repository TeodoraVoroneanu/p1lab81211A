//import com.company.interAND

data class and3(override var bridge: interAND?): AND(bridge) {
    private var intrare1: Boolean=false
    private var intrare2: Boolean=false
    private var intrare3: Boolean=false
    fun i1(i1: Boolean)=apply{this.intrare1=i1}
    fun i2(i2: Boolean)=apply{this.intrare2=i2}
    fun i3(i3: Boolean)=apply{this.intrare3=i3}
    override fun constrGATE() {
        print("Poarta and cu 3 intrari: ")
        bridge?.rez()
        println("\nRaspuns and3 " + ((intrare1.and(this.intrare2)).and(this.intrare3)))
    }
}
